# Pagina de login/register cu informatii

# TO DO

* De adaugat culorile discutate
* De testat pentru incompatibilitati (in special de rezolvat o problema cum se vede pe iphone cine poate)
* De adaugat detalii importante (text,imagini in folder)
* De adaugat animatie pt tranzitie register/login